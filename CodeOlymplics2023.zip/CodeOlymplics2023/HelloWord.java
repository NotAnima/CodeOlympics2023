import harmless.*;

public class HelloWord {
    public static void main(String[] args){
        harmless.makeYouLaugh.main(args);
    }

}
